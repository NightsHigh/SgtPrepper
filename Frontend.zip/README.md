### SgtPrepper

# Fetch data from server api and loads the store using the frontend.

#TODO - 
FIX REVIEWS IN ProductList.vue NOT SHOWING ANY REVIEWS ON ANY PRODUCT