<script>
import { useFetch } from '@/composables/useFetch'

</script>

<template>
    <div>
        <h2>Cart Component</h2>
    </div>
</template>