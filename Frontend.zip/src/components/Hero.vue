<template>
  <section
    class="w-full h-64 bg-[url('../../Header.png')] bg-cover bg-center"
  >
  </section>
<section class="-mt-12 rounded-3xl shadow-md bg-white w-6/8 mx-auto">
  <h3 class="text-4xl font-bold mb-4 pl-8">Velkommen til Stg. Prepper</h3>
  <div class="flex justify-between items-start text-gray-700 px-8">
    <p class="max-w-md">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sed explicabo amet neque consectetur ex excepturi eligendi consequatur quidem, quibusdam beatae voluptates ipsa fugit natus assumenda nobis adipisci quod omnis expedita.</p>
    <p class="max-w-md text-right">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Inventore distinctio obcaecati at, voluptatibus placeat quam minus temporibus fuga rerum accusantium officia sint iste nostrum repellendus deleniti earum commodi! Quos, accusantium.</p>
  </div>
</section>
</template>
