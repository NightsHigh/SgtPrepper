<template>
  <footer class="fixed bottom-0 w-full bg-white text-center py-2 shadow-inner bg-[url('../../Footer.png')] h-40">
  </footer>
</template>
