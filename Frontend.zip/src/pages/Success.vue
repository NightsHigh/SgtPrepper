<template>
  <section class="mx-auto max-w-4xl px-4 py-24 grid place-items-center">
    <div class="rounded-full bg-slate-800 text-white px-6 py-3 text-xl">
      Betaling Godkendt ✓
    </div>
  </section>
</template>
